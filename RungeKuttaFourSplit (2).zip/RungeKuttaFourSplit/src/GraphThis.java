
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.ApplicationFrame;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.*;



public class GraphThis extends ApplicationFrame {
    
    public GraphThis(final String title, XYSeriesCollection data, String graphTitle, String XTitle, String YTitle) {

        super(title);
        final JFreeChart chart = ChartFactory.createXYLineChart(
            graphTitle,
            XTitle, 
            YTitle, 
            data,
            PlotOrientation.VERTICAL,
            true,
            true,
            false
        );


        final ChartPanel chartPanel = new ChartPanel(chart);
        
        JFrame frame = new JFrame(title);
        frame.setTitle(title);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout(0,5));
        frame.add(chartPanel, BorderLayout.CENTER);
        chartPanel.setMouseWheelEnabled(true);
        chartPanel.setHorizontalAxisTrace(true);
        chartPanel.setVerticalAxisTrace(true);
        
        JButton toTable = new JButton("View Table");
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panel.add(toTable);
        
        final JComboBox trace = new JComboBox();
        panel.add(trace);

        toTable.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            Methods method = new Methods();
            DefaultTableModel tableModel = method.getTable();
            final JFrame tableFrame = new JFrame("Table");
            tableFrame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
            //Create and set up the content pane.
            final JTable table = new JTable(tableModel);
            JScrollPane scrollPane = new JScrollPane(table);
            table.setFillsViewportHeight(true);
            tableFrame.setContentPane(scrollPane);
            
            JMenuBar menuBar = new JMenuBar();  
            JMenu fileMenu = new JMenu("File");
            menuBar.add(fileMenu);
            JMenuItem exitAction = new JMenuItem("Exit");
            JMenuItem saveAction = new JMenuItem("Save");
            JMenuItem printAction = new JMenuItem("Print");
            fileMenu.add(exitAction);
            fileMenu.add(saveAction);
            fileMenu.add(printAction);
            tableFrame.setJMenuBar(menuBar);
            
            exitAction.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                tableFrame.setVisible(false);
                tableFrame.dispose();
            }
        });
            saveAction.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                JFileChooser fc = new JFileChooser();
                JFrame frame = new JFrame("Save");
                int userSelection = fc.showSaveDialog(frame);
                if (userSelection == JFileChooser.APPROVE_OPTION) {
                    File fileToSave = fc.getSelectedFile();
                    //System.out.println("Save as file: " + fileToSave.getAbsolutePath());
                    File file = new File(fileToSave.getAbsolutePath());
                    try{
                        if(!file.exists()){
                            file.createNewFile();
                        }
                        FileWriter fw = new FileWriter(file.getAbsoluteFile());
                        BufferedWriter bw = new BufferedWriter(fw);
                        for(int i = 0; i < table.getRowCount(); i++){ //loop for jtable column 
                            for(int j = 0; j < table.getColumnCount(); j++){ 
                                bw.write(table.getModel().getValueAt(i, j)+" ");
                            }
                            bw.newLine();
                        }
                        bw.close();
                        fw.close();
                    }catch(Exception ex){
                        ex.printStackTrace();
                    }
                }
            }
            
        });
            printAction.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                try {
                table.print();
              } catch (Exception pe) {
                System.err.println("Error printing: " + pe.getMessage());
              }
            }
        });
            
            //Display the window.
            tableFrame.pack();
            tableFrame.setVisible(true);
         }          
      });
        
        final String[] traceChoices = {"Enable Trace", "Disable Trace"};
        trace.setModel(new DefaultComboBoxModel(traceChoices));
        trace.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (traceChoices[0].equals(trace.getSelectedItem())) {
                    chartPanel.setHorizontalAxisTrace(true);
                    chartPanel.setVerticalAxisTrace(true);
                    chartPanel.repaint();
                } else {
                    chartPanel.setHorizontalAxisTrace(false);
                    chartPanel.setVerticalAxisTrace(false);
                    chartPanel.repaint();
                }
            }
        });
        
        final JButton auto = new JButton(new AbstractAction("Auto Zoom") {

            @Override
            public void actionPerformed(ActionEvent e) {
                chartPanel.restoreAutoBounds();
            }
        });
        
        panel.add(auto);
        
        frame.add(panel, BorderLayout.SOUTH);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        

    }
    
    
}