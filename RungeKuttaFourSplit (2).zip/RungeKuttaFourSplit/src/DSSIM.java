

/*
 * The MIT License
 *
 * Copyright 2016 Lord Commander.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

/**
 *
 * @author Lord Commander
 */

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import org.jfree.data.xy.XYSeriesCollection;

import javax.swing.*;

import java.io.*;
import javax.swing.table.DefaultTableModel;


public class DSSIM {
    public static void main(String[] args) {
        //now the initial stock values are outside they can be changed. Here they are set 
        //to the default we've played with before
        double inistock1 = 750;
        double inistock2 = 1;
        double inistock3 = 0;
        //window is made from the window class in the project. It runs the windows you created.
        //there are return methods for specific things but they may be redundant.
        
        
        Windows window = new Windows();
        
        window.graphOrChart();
        String viewChoice = window.viewChoice();
        window.graphLabels();
        String XTitle = window.returnXTitle();
        String YTitle = window.returnYTitle();
        String graphTitle = window.returnGraphTitle();
        window.initialVariables();
        window.methodChoice();
        String choice = window.returnMethodChoice();
        
        //you had dialogue boxes using "showConfirmDialog". This returns an int value
        //which is supposed to be handy for knowing what option was selected. I was guessing
        //that 0 would be the yes option. Could be wrong.
        if (window.option == 0){
            //instance of rungekutta to be run if the last dialogue is yes. Now rungekutta
            //has input arguments which will be handy later. 
            Methods method = new Methods(inistock1, inistock2, inistock3, window.t0, window.tf, window.step, choice);
            //data is created as an instance here.
            XYSeriesCollection data = method.returnData();
            
            if ("chart".equals(viewChoice)){
                final GraphThis graph = new GraphThis("DSSIM Graph", data, graphTitle, XTitle, YTitle);
//                graph.pack();       
//                RefineryUtilities.centerFrameOnScreen(graph);
//                graph.setVisible(true);
            }
            if("table".equals(viewChoice)){
            method = new Methods();
            DefaultTableModel tableModel = method.getTable();
            final JFrame tableFrame = new JFrame("Table");
            tableFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            //Create and set up the content pane.
            final JTable table = new JTable(tableModel);
            JScrollPane scrollPane = new JScrollPane(table);
            table.setFillsViewportHeight(true);
            tableFrame.setContentPane(scrollPane);
            
            JMenuBar menuBar = new JMenuBar();  
            JMenu fileMenu = new JMenu("File");
            menuBar.add(fileMenu);
            JMenuItem exitAction = new JMenuItem("Exit");
            JMenuItem saveAction = new JMenuItem("Save");
            JMenuItem printAction = new JMenuItem("Print");
            fileMenu.add(exitAction);
            fileMenu.add(saveAction);
            fileMenu.add(printAction);
            tableFrame.setJMenuBar(menuBar);
            
            exitAction.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                tableFrame.setVisible(false);
                tableFrame.dispose();
            }
        });
            saveAction.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                JFileChooser fc = new JFileChooser();
                JFrame frame = new JFrame("Save");
                int userSelection = fc.showSaveDialog(frame);
                if (userSelection == JFileChooser.APPROVE_OPTION) {
                    File fileToSave = fc.getSelectedFile();
                    //System.out.println("Save as file: " + fileToSave.getAbsolutePath());
                    File file = new File(fileToSave.getAbsolutePath());
                    try{
                        if(!file.exists()){
                            file.createNewFile();
                        }
                        FileWriter fw = new FileWriter(file.getAbsoluteFile());
                        BufferedWriter bw = new BufferedWriter(fw);
                        for(int i = 0; i < table.getRowCount(); i++){ 
                            for(int j = 0; j < table.getColumnCount(); j++){ 
                                bw.write(table.getModel().getValueAt(i, j)+" ");
                            }
                            bw.newLine();
                        }
                        bw.close();
                        fw.close();
                    }catch(Exception ex){
                        ex.printStackTrace();
                    }
                }
            }
            
        });
            printAction.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                try {
                table.print();
              } catch (Exception pe) {
                System.err.println("Error printing: " + pe.getMessage());
              }
            }
        });
            
            //Display the window.
            tableFrame.pack();
            tableFrame.setVisible(true);
         }          

            
        }        
    }
}
