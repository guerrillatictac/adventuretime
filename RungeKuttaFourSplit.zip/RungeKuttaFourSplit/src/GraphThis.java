
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;


public class GraphThis extends ApplicationFrame {
    public GraphThis(final String title, XYSeriesCollection data, String graphTitle, String XTitle, String YTitle) {

        super(title);
        final JFreeChart chart = ChartFactory.createXYLineChart(
            graphTitle,
            XTitle, 
            YTitle, 
            data,
            PlotOrientation.VERTICAL,
            true,
            true,
            false
        );


        final ChartPanel chartPanel = new ChartPanel(chart);
        
        JFrame frame = new JFrame(title);
        frame.setTitle(title);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout(0,5));
        frame.add(chartPanel, BorderLayout.CENTER);
        chartPanel.setMouseWheelEnabled(true);
        chartPanel.setHorizontalAxisTrace(true);
        chartPanel.setVerticalAxisTrace(true);
        
        JButton toTable = new JButton("View Table");
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panel.add(toTable);
        
        frame.add(panel, BorderLayout.SOUTH);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        
        
        toTable.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            Methods method = new Methods();
            DefaultTableModel tableModel = method.getTable();
            JFrame frame = new JFrame("Table");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            //Create and set up the content pane.
            JTable table = new JTable(tableModel);
            JScrollPane scrollPane = new JScrollPane(table);
            table.setFillsViewportHeight(true);
            frame.setContentPane(scrollPane);
            //Display the window.
            frame.pack();
            frame.setVisible(true);
         }          
      });

    }
}